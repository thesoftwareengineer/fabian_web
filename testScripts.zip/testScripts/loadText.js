$(document).ready(function () {
    $.get("Scripts/", function (data) {
        var file_list = $(data).find('#files').text();
        file_list = file_list.split('\n').sort();
        console.log(file_list);
        //        $.ajax({
        //            url: 'Scripts/' + file_list[1],
        //            success: function (result) {
        //                result_id = $(result).find('#body-section');
        //                console.log(result_id.text())
        //                $("#posts").append('<p>' + result_id.text() + '</p>');
        //            }
        //        });
        //        $.ajax({
        //            url: 'Scripts/' + file_list[3],
        //            success: function (result) {
        //                result_id = $(result).find('#body-section');
        //                console.log(result_id.text())
        //                $("#posts").append('<a>' + result_id.text() + '</a>');
        //            }
        //        });
        $('#post1').load('Scripts/' + file_list[file_list.length - 1]);
        console.log('Srcipts/' + file_list[file_list.length - 1]);
        $('#post2').load('Srcipts/' + file_list[file_list.length - 2]);
        console.log('Srcipts/' + file_list[file_list.length - 2]);
        $('#post2').load('Srcipts/' + file_list[file_list.length - 3]);
        console.log('Srcipts/' + file_list[file_list.length - 3]);
    });
});